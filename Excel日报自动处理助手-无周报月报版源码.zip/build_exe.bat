﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto :error
call .venv\Scripts\python.exe -m pip install --upgrade pip
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto :error
call .venv\Scripts\pyinstaller.exe --onefile --windowed --noconfirm --clean ^
  --hidden-import=openpyxl ^
  --hidden-import=openpyxl.styles ^
  --hidden-import=openpyxl.utils ^
  --name "Excel日报自动处理助手" main.py
if errorlevel 1 goto :error
echo Build complete: dist\Excel日报自动处理助手.exe
exit /b 0
:error
echo Build failed.
exit /b 1
