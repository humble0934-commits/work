# Excel月报自动汇总助手

Windows 10/11 月报汇总工具，使用 Python 3.12、tkinter 和 openpyxl。

当前版本只保留月报汇总功能，不包含周报标签页、周报文件选择、周报日期范围、
周报工作表复制、周报 SUMIF、周报排序或周报汇总公式代码。

## 功能

- 选择多个品牌日报 XLSX 文件。
- 选择多个品牌月报 XLSX 文件。
- 输入目标月份 `YYYY/MM`。
- 自动按品牌模糊匹配日报和月报。
- 在 Windows 桌面生成处理后的月报，并保持原月报文件名。
- 保留现有月报字段识别、公式生成、排序、条件格式、颜色、边框、合并单元格、
  行高和列宽处理逻辑。

## 源码运行

```bat
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe main.py
```

## 打包

运行：

```bat
build_exe.bat
```

输出：

```text
dist\Excel月报自动汇总助手.exe
```
